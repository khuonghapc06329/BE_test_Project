let Name = document.getElementById("name");
let Email = document.getElementById("email");
let Phone = document.getElementById("phone");
let Company = document.getElementById("company");
let Message = document.getElementById("message");

document
  .getElementById("contactForm")
  .addEventListener("submit", function (event) {
    event.preventDefault(); 

   
    const errors = document.querySelectorAll(".error");
    errors.forEach((error) => error.remove());

    
    const inputs = document.querySelectorAll(
      ".form-group input, .form-group textarea"
    );
    inputs.forEach((input) => input.classList.remove("error-input"));

   
    let valid = true;
    let errorMessages = [];

    const name = document.getElementById("name");
    if (name.value.trim() === "") {
      valid = false;
      showError(name, "Name is required");
      errorMessages.push("Name is required");
      name.style.border = "1px solid red";
    }else{
      name.style.border = "";
    }

    const email = document.getElementById("email");
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email.value.trim() === "" || !emailPattern.test(email.value)) {
      valid = false;
      showError(email, "Valid email is required");
      errorMessages.push("Valid email is required");
      email.style.border = "1px solid red";
    }else{
      email.style.border = "";
    }

   
    const phone = document.getElementById("phone");
    const phonePattern = /^[0-9\-\(\)\s]+$/;
    if (phone.value.trim() === "" || !phonePattern.test(phone.value)) {
      valid = false;
      showError(phone, "Valid phone number is required");
      errorMessages.push("Valid phone number is required");
      phone.style.border = "1px solid red";
    }else{
      phone.style.border = "";
    }

   
    const company = document.getElementById("company");
    if (company.value.trim() === "") {
      valid = false;
      showError(company, "Company is required");
      errorMessages.push("Company is required");
      company.style.border = "1px solid red";
    }else{
      company.style.border = "";
    }

    const message = document.getElementById("message");
    if (message.value.trim() === "") {
      valid = false;
      showError(message, "Message is required");
      errorMessages.push("Message is required");
      message.style.border = "1px solid red";
    }else{
      message.style.border = "";
    }

    
    const notificationContainer = document.querySelector(
      ".notification-container"
    );
    if (!valid) {
      notificationContainer.querySelector(".text-muted").innerText =
        "Ooops, something went wrong.";
      notificationContainer
        .querySelector(".btn-custom")
        .addEventListener("click", function () {
          notificationContainer.style.display = "none"; 
        });
      notificationContainer.style.display = "block"; 
    } else {
    
      this.submit();
    }
  });

function showError(element, message) {
  const error = document.createElement("div");
  error.className = "error text-danger";
  error.innerText = message;
  element.parentNode.appendChild(error);
  element.classList.add("error-input"); 
}
