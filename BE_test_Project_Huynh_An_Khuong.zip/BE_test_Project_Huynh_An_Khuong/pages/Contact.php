<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './vendor/autoload.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $company = trim($_POST["company"]);
    $message = trim($_POST["message"]);

    $errors = [];
    if (empty($name)) $errors['name'] = 'Name is required';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Valid email is required';
    if (empty($phone)) $errors['phone'] = 'Phone is required';
    if (empty($company)) $errors['company'] = 'Company is required';
    if (empty($message)) $errors['message'] = 'Message is required';


    if (empty($errors)) {
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'khuonghapc06329@fpt.edu.vn';
            $mail->Password   = 'rspctxfwuaypoyuk';
            $mail->Port       = 587;

            $mail->setFrom('khuonghapc06329@fpt.edu.vn', 'Khuong Huynh');
            $mail->addAddress($email);

            $mail->isHTML(true);
            $mail->Subject = 'Thank You for Your Message';
            $mail->Body = "
                <div class='result-container'>
                    <h1>Thank you for contacting us</h1>
                    <p style='margin-top:40px'>We will be back in touch with you within one business day using the information you just provided below:</p>
                    <p style='margin-top:40px'><span>Name:</span> " . htmlspecialchars($name) . "</p>
                    <p><span>Phone:</span> " . htmlspecialchars($phone) . "</p>
                    <p><span>Email Address:</span> <a href='mailto:" . htmlspecialchars($email) . "'>" . htmlspecialchars($email) . "</a></p>
                    <p><span>Company:</span> " . htmlspecialchars($company) . "</p>
                    <p><span>Message:</span> " . htmlspecialchars($message) . "</p>
                </div>
            ";

            // Gửi email
            $mail->send();
            echo "
                <script>
                    // Mở một tab mới với URL chứa các tham số GET
                    window.open('index.php?act=result&name=" . urlencode($name) .
                "&phone=" . urlencode($phone) .
                "&email=" . urlencode($email) .
                "&company=" . urlencode($company) .
                "&message=" . urlencode($message) . "', '_blank');
                </script>
            ";
            $name = $phone = $email = $company = $message = '';
        } catch (Exception $e) {
            echo "Could not send the email. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        foreach ($errors as $error) {
            echo "<p class='text-danger'>$error</p>";
        }
    }
}
?>


<div class="contact-form-container border border-success">
    <div class="form-section" style="border-radius:none">
        <div class="nav_title">
            <h3>Send us a Message</h3>
            <img style="width: 10%" src="./image/sent.png" alt="">
        </div>

        <form id="contactForm" class="mt-4" action="index.php?act=home" method="POST">
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="name">Your Name</label>
                        <input type="text" id="name" name="name" placeholder="Dexter Morgan" value="<?php echo htmlspecialchars(isset($name) ? $name : ''); ?>">
                        <?php if (isset($errors['name'])): ?>
                            <div class="text-danger"><?php echo htmlspecialchars($errors['name']); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" placeholder="dextermorgan@hisoffice.com" value="<?php echo htmlspecialchars(isset($email) ? $email : ''); ?>">
                        <?php if (isset($errors['email'])): ?>
                            <div class="text-danger"><?php echo htmlspecialchars($errors['email']); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="text" id="phone" name="phone" placeholder="(800) 800-900-100" value="<?php echo htmlspecialchars(isset($phone) ? $phone : ''); ?>">
                        <?php if (isset($errors['phone'])): ?>
                            <div class="text-danger"><?php echo htmlspecialchars($errors['phone']); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="company">Company</label>
                        <input type="text" id="company" name="company" placeholder="Morgan & Meat Enterprises" value="<?php echo htmlspecialchars(isset($company) ? $company : ''); ?>">
                        <?php if (isset($errors['company'])): ?>
                            <div class="text-danger"><?php echo htmlspecialchars($errors['company']); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="message">Message</label>
                <textarea id="message" name="message" placeholder="Hi, do you have a moment to talk abo..."><?php echo htmlspecialchars(isset($message) ? $message : ''); ?></textarea>
                <?php if (isset($errors['message'])): ?>
                    <div class="text-danger"><?php echo htmlspecialchars($errors['message']); ?></div>
                <?php endif; ?>
            </div>
            <div class="text-end">
                <button class="rounded-3" type="submit">Send</button>
            </div>
        </form>
    </div>
    <div class="contact-info-section d-flex flex-column">
        <h2>Contact Information</h2>
        <p class="mt-5"><i class="fa-solid fa-location-dot fa-2xl"></i><span class="mx-2"> 360 King Street<br>Feasterville Trevose, PA 19053</span></p>
        <p class="mt-5"><i class="fa-solid fa-mobile-screen-button fa-2xl"></i><span class="mx-2">(800) 900-200-300</span></p>
        <p class="mt-5"><i class="fa-regular fa-envelope fa-2xl"></i> <span class="mx-2">info@...com</span></p>
        <div class="mt-5">
            <i class="fa-brands fa-twitter fa-2xl"></i>
            <i id="icon" class="fa-brands fa-linkedin fa-2xl"></i>
            <i id="icon" class="fa-brands fa-instagram fa-2xl"></i>
        </div>
    </div>
</div>
<div class="notification-container">
    <h1 class="h4">Face-plant!</h1>
    <p class="text-muted">Ooops, something went wrong.</p>
    <div class="icon"><i class="fa-regular fa-circle-xmark fa-xl"></i></div>
    <a href="#" class="btn btn-custom">Try again</a>
</div>