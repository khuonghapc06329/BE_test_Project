
<div class="container">
    <div class="error-container">
        <h1 class="display-1">404</h1>
        <h2 class="display-4">Page Not Found</h2>
        <p class="lead">Sorry, the page you are looking for does not exist.</p>
        <a href="/index.php" class="btn btn-custom">Go to Homepage</a>
    </div>
</div>