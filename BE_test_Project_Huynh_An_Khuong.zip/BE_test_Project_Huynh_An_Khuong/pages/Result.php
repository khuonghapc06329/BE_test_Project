<?php

$name = isset($_GET['name']) ? htmlspecialchars($_GET['name']) : '';
$phone = isset($_GET['phone']) ? htmlspecialchars($_GET['phone']) : '';
$email = isset($_GET['email']) ? htmlspecialchars($_GET['email']) : '';
$company = isset($_GET['company']) ? htmlspecialchars($_GET['company']) : '';
$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';

$hasData = !empty($name) || !empty($phone) || !empty($email) || !empty($company) || !empty($message);
?>
<?php if (!$hasData) { ?>
    <div class="notification-container-error">
        <h1 class="h4">Face-plant!</h1>
        <p class="text-muted">Ooops, No data, Please fill in the form</p>
        <div class="icon"><i class="fa-regular fa-circle-xmark fa-xl"></i></div>
        <a href="index.php?act=home" class="btn btn-custom">Try again</a>
    </div>
    <script>
        let errorPopup = document.getElementsByClassName('notification-container-error');
        errorPopup.style.display = "block";
    </script>
<?php } else { ?>

    <div class="result-container">
        <h1>Thank you for contacting us</h1>
        <p style="margin-top:40px">We will be back in touch with you within one business day using the information you just provided below:</p>
        <p style="margin-top:40px"><span>Name:</span> <?php echo $name; ?></p>
        <p><span>Phone:</span> <?php echo $phone; ?></p>
        <p><span>Email Address:</span> <a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></p>
        <p><span>Company:</span> <?php echo $company; ?></p>
        <p><span>Message:</span> <?php echo $message; ?></p>
    </div>

    <div class="notification-container-mail">
        <h1 class="h4">Success!</h1>
        <p class="text-muted">Your message has been sent successfully.</p>
        <p class="text-muted">Please check your email!</p>
        <div class="icon"><i class="fa-solid fa-envelope-circle-check fa-xl"></i></div>
        <a href="#" id="btn-cancel" class="btn btn-custom">Cancel</a>
        <a href="index.php?act=home" class="btn btn-try">Back to Home</a>
    </div>
    <script>
        document.getElementById('btn-cancel').addEventListener('click', function() {
            document.querySelector('.notification-container-mail').style.display = 'none';
        });
    </script>
<?php } ?>